import 'package:get/get.dart';

class DetailController extends GetxController{

}